# Learning to use the Met Office IRIS package.

https://scitools-iris.readthedocs.io/en/latest/generated/gallery/index.html

https://scitools-iris.readthedocs.io/en/latest/userguide/index.html

I've registered as a personal-use account with the CEDA archive so I can download Hadley UK 1km grid data.

user = melliott , Elliott1

Other met office resources:

python - getting met office observation data from datapoint API: https://gist.github.com/springcoil/21d63aef85a3739655a0

met office github: https://github.com/MetOffice   , eg https://github.com/MetOffice/aws-earth-examples/blob/master/examples/1.%20Getting%20Started.ipynb


Details for individual surface (land or sea based) observation stations aren't easy to find. They won't always be listed in the data catalogue directly unless there are data from there other than those in the MIDAS datasets. To find out more details about these you can find them in the MIDAS Station Search tool instead.

https://www.metoffice.gov.uk/research/climate/maps-and-data/historic-station-data


```python
# Example of a Polar Stereographic Plot
# Demonstrates plotting data that are defined on a polar stereographic projection.

import matplotlib.pyplot as plt

import iris
import iris.plot as iplt
import iris.quickplot as qplt
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.ticker
import datetime
from iris.time import PartialDateTime

def main():
    file_path = iris.sample_data_path("toa_brightness_stereographic.nc")
    cube = iris.load_cube(file_path)
    qplt.contourf(cube)
    ax = plt.gca()
    ax.coastlines()
    ax.gridlines()
    iplt.show()


if __name__ == "__main__":
    main()
```

    C:\Users\User\AppData\Local\Temp\ipykernel_26848\3489412819.py:17: FutureWarning: Ignoring a datum in netCDF load for consistency with existing behaviour. In a future version of Iris, this datum will be applied. To apply the datum when loading, use the iris.FUTURE.datum_support flag.
      cube = iris.load_cube(file_path)
    


    
![png](output_1_1.png)
    



```python
# Multi-Line Temperature Profile Plot.

import matplotlib.pyplot as plt

import iris
import iris.plot as iplt
import iris.quickplot as qplt


def main():
    fname = iris.sample_data_path("air_temp.pp")

    # Load exactly one cube from the given file.
    temperature = iris.load_cube(fname)

    # We only want a small number of latitudes, so filter some out
    # using "extract".
    temperature = temperature.extract(
        iris.Constraint(latitude=lambda cell: 68 <= cell < 78)
    )

    for cube in temperature.slices("longitude"):
        # Create a string label to identify this cube (i.e. latitude: value).
        cube_label = "latitude: %s" % cube.coord("latitude").points[0]

        # Plot the cube, and associate it with a label.
        qplt.plot(cube, label=cube_label)

    # Add the legend with 2 columns.
    plt.legend(ncol=2)

    # Put a grid on the plot.
    plt.grid(True)

    # Tell matplotlib not to extend the plot axes range to nicely
    # rounded numbers.
    plt.axis("tight")

    # Finally, show it.
    iplt.show()


if __name__ == "__main__":
    main()
```


    
![png](output_2_0.png)
    



```python
# Fitting a Polynomial
# This example demonstrates computing a polynomial fit to 1D data from an Iris cube, adding the fit to the cube’s metadata, and plotting both the 1D data and the fit.
# I had to install another package for this to run: conda install -c conda-forge nc-time-axis

import matplotlib.pyplot as plt
import numpy as np

import iris
import iris.quickplot as qplt


def main():
    # Load some test data.
    fname = iris.sample_data_path("A1B_north_america.nc")
    cube = iris.load_cube(fname)

    # Extract a single time series at a latitude and longitude point.
    location = next(cube.slices(["time"]))

    # Calculate a polynomial fit to the data at this time series.
    x_points = location.coord("time").points
    y_points = location.data
    degree = 2

    p = np.polyfit(x_points, y_points, degree)
    y_fitted = np.polyval(p, x_points)

    # Add the polynomial fit values to the time series to take
    # full advantage of Iris plotting functionality.
    long_name = "degree_{}_polynomial_fit_of_{}".format(degree, cube.name())
    fit = iris.coords.AuxCoord(y_fitted, long_name=long_name, units=location.units)
    location.add_aux_coord(fit, 0)

    qplt.plot(location.coord("time"), location, label="data")
    qplt.plot(
        location.coord("time"),
        location.coord(long_name),
        "g-",
        label="polynomial fit",
    )
    plt.legend(loc="best")
    plt.title("Trend of US air temperature over time")

    qplt.show()


if __name__ == "__main__":
    main()
```

    C:\Users\User\AppData\Local\Temp\ipykernel_16208\3208586480.py:14: FutureWarning: Ignoring a datum in netCDF load for consistency with existing behaviour. In a future version of Iris, this datum will be applied. To apply the datum when loading, use the iris.FUTURE.datum_support flag.
      cube = iris.load_cube(fname)
    


    
![png](output_3_1.png)
    



```python
# Seasonal Ensemble Model Plots

# This example demonstrates the loading of a lagged ensemble dataset from the GloSea4 model, which is then used to produce two types of plot:
#    The first shows the “postage stamp” style image with an array of 14 images, one for each ensemble member with a shared colorbar. (The missing image in this example represents ensemble member number 6 which was a failed run)
#    The second plot shows the data limited to a region of interest, in this case a region defined for forecasting ENSO (El Nino-Southern Oscillation), which, for the purposes of this example, has had the ensemble mean subtracted from each ensemble member to give an anomaly surface temperature. In practice a better approach would be to take the climatological mean, calibrated to the model, from each ensemble member.
# An ensemble means multiple model runs.

import matplotlib.pyplot as plt
import matplotlib.ticker
import numpy as np

import iris
import iris.plot as iplt


def realization_metadata(cube, field, fname):
    """Modify the cube's metadata to add a "realization" coordinate.

    A function which modifies the cube's metadata to add a "realization"
    (ensemble member) coordinate from the filename if one doesn't already exist
    in the cube.

    """
    # Add an ensemble member coordinate if one doesn't already exist.
    if not cube.coords("realization"):
        # The ensemble member is encoded in the filename as *_???.pp where ???
        # is the ensemble member.
        realization_number = fname[-6:-3]
        realization_coord = iris.coords.AuxCoord(
            np.int32(realization_number), "realization", units="1"
        )
        cube.add_aux_coord(realization_coord)


def main():
    # Create a constraint to extract surface temperature cubes which have a
    # "realization" coordinate.
    constraint = iris.Constraint("surface_temperature", realization=lambda value: True)
    # Use this to load our ensemble.  The callback ensures all our members
    # have the "realization" coordinate and therefore they will all be loaded.
    surface_temp = iris.load_cube(
        iris.sample_data_path("GloSea4", "ensemble_???.pp"),
        constraint,
        callback=realization_metadata,
    )

    # -------------------------------------------------------------------------
    # Plot #1: Ensemble postage stamps
    # -------------------------------------------------------------------------

    # For the purposes of this example, take the last time element of the cube.
    # First get hold of the last time by slicing the coordinate.
    last_time_coord = surface_temp.coord("time")[-1]
    last_timestep = surface_temp.subset(last_time_coord)

    # Find the maximum and minimum across the dataset.
    data_min = np.min(last_timestep.data)
    data_max = np.max(last_timestep.data)

    # Create a wider than normal figure to support our many plots.
    plt.figure(figsize=(12, 6), dpi=100)

    # Also manually adjust the spacings which are used when creating subplots.
    plt.gcf().subplots_adjust(
        hspace=0.05,
        wspace=0.05,
        top=0.95,
        bottom=0.05,
        left=0.075,
        right=0.925,
    )

    # Iterate over all possible latitude longitude slices.
    for cube in last_timestep.slices(["latitude", "longitude"]):
        # Get the ensemble member number from the ensemble coordinate.
        ens_member = cube.coord("realization").points[0]

        # Plot the data in a 4x4 grid, with each plot's position in the grid
        # being determined by ensemble member number.  The special case for the
        # 13th ensemble member is to have the plot at the bottom right.
        if ens_member == 13:
            plt.subplot(4, 4, 16)
        else:
            plt.subplot(4, 4, ens_member + 1)

        # Plot with 50 evenly spaced contour levels (49 intervals).
        cf = iplt.contourf(cube, 49, vmin=data_min, vmax=data_max)

        # Add coastlines.
        plt.gca().coastlines()

    # Make an axes to put the shared colorbar in.
    colorbar_axes = plt.gcf().add_axes([0.35, 0.1, 0.3, 0.05])
    colorbar = plt.colorbar(cf, colorbar_axes, orientation="horizontal")
    colorbar.set_label(last_timestep.units)

    # Limit the colorbar to 8 tick marks.
    colorbar.locator = matplotlib.ticker.MaxNLocator(8)
    colorbar.update_ticks()

    # Get the time for the entire plot.
    time = last_time_coord.units.num2date(last_time_coord.bounds[0, 0])

    # Set a global title for the postage stamps with the date formatted by
    # "monthname year".
    time_string = time.strftime("%B %Y")
    plt.suptitle(f"Surface temperature ensemble forecasts for {time_string}")

    iplt.show()

    # -------------------------------------------------------------------------
    # Plot #2: ENSO plumes
    # -------------------------------------------------------------------------

    # Nino 3.4 lies between: 170W and 120W, 5N and 5S, so use the intersection
    # method to restrict to this region.
    nino_cube = surface_temp.intersection(latitude=[-5, 5], longitude=[-170, -120])

    # Calculate the horizontal mean for the nino region.
    mean = nino_cube.collapsed(["latitude", "longitude"], iris.analysis.MEAN)

    # Calculate the ensemble mean of the horizontal mean.
    ensemble_mean = mean.collapsed("realization", iris.analysis.MEAN)

    # Take the ensemble mean from each ensemble member.
    mean -= ensemble_mean

    plt.figure()

    for ensemble_member in mean.slices(["time"]):
        # Draw each ensemble member as a dashed line in black.
        iplt.plot(ensemble_member, "--k")

    plt.title("Mean temperature anomaly for ENSO 3.4 region")
    plt.xlabel("Time")
    plt.ylabel("Temperature anomaly / K")

    iplt.show()


if __name__ == "__main__":
    main()
```


    
![png](output_4_0.png)
    


    C:\Users\User\anaconda3\Lib\site-packages\iris\cube.py:3859: UserWarning: Collapsing spatial coordinate 'latitude' without weighting
      warnings.warn(msg.format(coord.name()))
    C:\Users\User\anaconda3\Lib\site-packages\iris\coords.py:2237: UserWarning: Cannot check if coordinate is contiguous: Invalid operation for 'latitude', with 0 bound(s). Contiguous bounds are only defined for 1D coordinates with 2 bounds. Metadata may not be fully descriptive for 'latitude'. Ignoring bounds.
      warnings.warn(msg.format(str(exc), self.name()))
    C:\Users\User\anaconda3\Lib\site-packages\iris\coords.py:2237: UserWarning: Cannot check if coordinate is contiguous: Invalid operation for 'longitude', with 0 bound(s). Contiguous bounds are only defined for 1D coordinates with 2 bounds. Metadata may not be fully descriptive for 'longitude'. Ignoring bounds.
      warnings.warn(msg.format(str(exc), self.name()))
    C:\Users\User\anaconda3\Lib\site-packages\iris\coords.py:2237: UserWarning: Cannot check if coordinate is contiguous: Invalid operation for 'realization', with 0 bound(s). Contiguous bounds are only defined for 1D coordinates with 2 bounds. Metadata may not be fully descriptive for 'realization'. Ignoring bounds.
      warnings.warn(msg.format(str(exc), self.name()))
    C:\Users\User\anaconda3\Lib\site-packages\iris\coords.py:2227: UserWarning: Collapsing a multi-dimensional coordinate. Metadata may not be fully descriptive for 'forecast_period'.
      warnings.warn(msg.format(self.name()))
    C:\Users\User\anaconda3\Lib\site-packages\iris\coords.py:2227: UserWarning: Collapsing a multi-dimensional coordinate. Metadata may not be fully descriptive for 'forecast_reference_time'.
      warnings.warn(msg.format(self.name()))
    


    
![png](output_4_2.png)
    


# Now working through the IRIS user guide

# A Simple Cube Example - what is a cube?
Suppose we have some gridded data which has 24 air temperature readings (in Kelvin) which is located at 4 different longitudes, 2 different latitudes and 3 different heights. Our data array can be represented pictorially:

Where dimensions 0, 1, and 2 have lengths 3, 2 and 4 respectively.

The Iris cube to represent this data would consist of:

    a standard name of air_temperature and a unit of kelvin

    a data array of shape (3, 2, 4)

    a coordinate, mapping to dimension 0, consisting of:

        a standard name of height and unit of meters

        an array of length 3 representing the 3 height points

    a coordinate, mapping to dimension 1, consisting of:

        a standard name of latitude and unit of degrees

        an array of length 2 representing the 2 latitude points

        a coordinate system such that the latitude points could be fully located on the globe

    a coordinate, mapping to dimension 2, consisting of:

        a standard name of longitude and unit of degrees

        an array of length 4 representing the 4 longitude points

        a coordinate system such that the longitude points could be fully located on the globe

Pictorially the cube has taken on more information than a simple array: - each dimension of the 3D array now has information (metadata) about its name and units etc.

# Loading IRIS cubes

To load a single file into a list of Iris cubes the iris.load() function is used:

import iris
filename = '/path/to/file'
cubes = iris.load(filename)

Iris will attempt to return as few cubes as possible by collecting together multiple fields with a shared standard name into a single multidimensional cube.

The iris.load() function automatically recognises the format of the given files and attempts to produce Iris Cubes from their contents.

Note

Currently there is support for CF NetCDF, GRIB 1 & 2, PP and FieldsFiles file formats with a framework for this to be extended to custom formats.

In order to find out what has been loaded, the result can be printed:


```python
import iris
filename = iris.sample_data_path('uk_hires.pp')
cubes = iris.load(filename)
print(cubes)
```

    0: air_potential_temperature / (K)     (time: 3; model_level_number: 7; grid_latitude: 204; grid_longitude: 187)
    1: surface_altitude / (m)              (grid_latitude: 204; grid_longitude: 187)
    

This shows that there were 2 cubes as a result of loading the file, they were: air_potential_temperature and surface_altitude.

The surface_altitude cube was 2 dimensional with:

    the two dimensions have extents of 204 and 187 respectively and are represented by the grid_latitude and grid_longitude coordinates.

The air_potential_temperature cubes were 4 dimensional with:

    the same length grid_latitude and grid_longitude dimensions as surface_altitide

    a time dimension of length 3

    a model_level_number dimension of length 7

Note

The result of iris.load() is always a iris.cube.CubeList (even if it only contains one iris.cube.Cube - see Strict Loading). Anything that can be done with a Python list can be done with an iris.cube.CubeList.

The order of this list should not be relied upon. Ways of loading a specific cube or cubes are covered in Constrained Loading and Strict Loading.

Hint

Throughout this user guide you will see the function iris.sample_data_path being used to get the filename for the resources used in the examples. The result of this function is just a string.

Using this function allows us to provide examples which will work across platforms and with data installed in different locations, however in practice you will want to use your own strings:

filename = '/path/to/file'
cubes = iris.load(filename)

To get the air potential temperature cube from the list of cubes returned by iris.load() in the previous example, list indexing can be used:


```python
import iris
filename = iris.sample_data_path('uk_hires.pp')
cubes = iris.load(filename)
# get the first cube (list indexing is 0 based)
air_potential_temperature = cubes[0]
print(air_potential_temperature)
```

    air_potential_temperature / (K)     (time: 3; model_level_number: 7; grid_latitude: 204; grid_longitude: 187)
        Dimension coordinates:
            time                             x                      -                 -                    -
            model_level_number               -                      x                 -                    -
            grid_latitude                    -                      -                 x                    -
            grid_longitude                   -                      -                 -                    x
        Auxiliary coordinates:
            forecast_period                  x                      -                 -                    -
            level_height                     -                      x                 -                    -
            sigma                            -                      x                 -                    -
            surface_altitude                 -                      -                 x                    x
        Derived coordinates:
            altitude                         -                      x                 x                    x
        Scalar coordinates:
            forecast_reference_time     2009-11-19 04:00:00
        Attributes:
            STASH                       m01s00i004
            source                      'Data from Met Office Unified Model'
            um_version                  '7.3'
    

Specifying a name as a constraint argument to iris.load() will mean only cubes with matching name will be returned:


```python
filename = iris.sample_data_path('uk_hires.pp')
cubes = iris.load(filename, 'surface_altitude')
```

IRIS uses "lazy loading" of data, ie it only loads the minimum required. So it won't load the full data when first used - it just loads the metadata (eg that required to print the high level info).

The iris.Constraint class can be used to restrict coordinate values on load. For example, to constrain the load to match a specific model_level_number:


```python
filename = iris.sample_data_path('uk_hires.pp')
level_10 = iris.Constraint(model_level_number=10)
cubes = iris.load(filename, level_10)
```

# Saving Iris Cubes

Iris supports the saving of cubes and cube lists to:

    CF netCDF (version 1.7)

    GRIB edition 2 (if iris-grib is installed)

    Met Office PP

The iris.save() function saves one or more cubes to a file.

If the filename includes a supported suffix then Iris will use the correct saver and the keyword argument saver is not required.


```python
# Save a cube to PP
iris.save(cubes[0], "myfile.pp")
# Save a cube list to a PP file, appending to the contents of the file
# if it already exists
iris.save(cubes, "myfile.pp", append=True)

# Save a cube to netCDF, defaults to NETCDF4 file format
iris.save(cubes[0], "myfile.nc")
# Save a cube list to netCDF, using the NETCDF3_CLASSIC storage option
iris.save(cubes, "myfile.nc", netcdf_format="NETCDF3_CLASSIC") # .nc does not allow "append" saving.
```

# Navigating a Cube
After loading any cube, you will want to investigate precisely what it contains. This section is all about accessing and manipulating the metadata contained within a cube.

print(cube) returns a high level "string" containing the metadata.

Other, more verbose, functions also exist which give information on what you can do with any given variable. In most cases it is reasonable to ignore anything starting with a “_” (underscore) or a “__” (double underscore):

    dir(cube)
    help(cube)

### Working With Cubes

Every cube has a standard name, long name and units which are accessed with Cube.standard_name, Cube.long_name and Cube.units respectively:

    print(cube.standard_name)
    print(cube.long_name)
    print(cube.units)

Interrogating these with the standard type() function will tell you that standard_name and long_name are either a string or None, and units is an instance of iris.unit.Unit. A more in depth discussion on the cube units and their functional effects can be found at the end of Cube Maths.

You can access a string representing the “name” of a cube with the Cube.name() method:

    print(cube.name())

The result of which is always a string.

Each cube also has a numpy array which represents the phenomenon of the cube which can be accessed with the Cube.data attribute. As you can see the type is a numpy n-dimensional array:

    print(type(cube.data))

Note

When loading from most file formats in Iris, the data itself is not loaded until the first time that the data is requested. Hence you may have noticed that running the previous command for the first time takes a little longer than it does for subsequent calls.

For this reason, when you have a large cube it is strongly recommended that you do not access the cube’s data unless you need to. For convenience shape and ndim attributes exists on a cube, which can tell you the shape of the cube’s data without loading it:

    print(cube.shape)
    print(cube.ndim)




```python
print(air_potential_temperature.shape)  # (3, 7, 204, 187)
```

    (3, 7, 204, 187)
    


```python
print(air_potential_temperature.ndim) # 4 
```

    4
    


```python
print(air_potential_temperature.units) # K
```

    K
    


```python
print(air_potential_temperature.standard_name) # air_potential_temperature
```

    air_potential_temperature
    


```python
print(air_potential_temperature.long_name) # None
```

    None
    

You can change the units of a cube using the convert_units() method. For example:

    cube.convert_units('celsius')

As well as changing the value of the units attribute this will also convert the values in data. To replace the units without modifying the data values one can change the units attribute directly.

Some cubes represent a processed phenomenon which are represented with cell methods, these can be accessed on a cube with the Cube.cell_methods attribute:

    print(cube.cell_methods)

### Accessing Coordinates on the Cube

A cube’s coordinates can be retrieved via Cube.coords. A simple for loop over the coords can print a coordinate’s name():

    for coord in cube.coords():
        print(coord.name())

Alternatively, we can use list comprehension to store the names in a list:

    coord_names = [coord.name() for coord in cube.coords()]

The result is a basic Python list which could be sorted alphabetically and joined together:

    print(', '.join(sorted(coord_names)))
    forecast_period, forecast_reference_time, grid_latitude, grid_longitude, time

To get an individual coordinate given its name, the Cube.coord method can be used:

    coord = cube.coord('grid_latitude')
    print(type(coord))

Every coordinate has a Coord.standard_name, Coord.long_name, and Coord.units attribute:

    print(coord.standard_name)
    print(coord.long_name)
    print(coord.units)

Additionally every coordinate can provide its points and bounds numpy array. If the coordinate has no bounds None will be returned:

    print(type(coord.points))
    print(type(coord.bounds))


# Subsetting a Cube

The Loading Iris Cubes section of the user guide showed how to load data into multidimensional Iris cubes. However it is often necessary to reduce the dimensionality of a cube down to something more appropriate and/or manageable.

Iris provides several ways of reducing both the amount of data and/or the number of dimensions in your cube depending on the circumstance. In all cases the subset of a valid cube is itself a valid cube.

### Cube Extraction

A subset of a cube can be “extracted” from a multi-dimensional cube in order to reduce its dimensionality:

    import iris
    filename = iris.sample_data_path('space_weather.nc')
    cube = iris.load_cube(filename, 'electron density')
    equator_slice = cube.extract(iris.Constraint(grid_latitude=0))
    print(equator_slice)
electron density / (1E11 e/m^3)     (height: 29; grid_longitude: 31)
    Dimension coordinates:
        height                             x                   -
        grid_longitude                     -                   x
    Auxiliary coordinates:
        latitude                           -                   x
        longitude                          -                   x
    Scalar coordinates:
        grid_latitude               0.0 degrees
    Attributes:
        Conventions                 'CF-1.5'

In this example we start with a 3 dimensional cube, with dimensions of height, grid_latitude and grid_longitude, and use iris.Constraint to extract every point where the latitude is 0, resulting in a 2d cube with axes of height and grid_longitude.

Warning

Caution is required when using equality constraints with floating point coordinates such as grid_latitude. Printing the points of a coordinate does not necessarily show the full precision of the underlying number and it is very easy to return no matches to a constraint when one was expected. This can be avoided by using a function as the argument to the constraint:

    def near_zero(cell):
       """Returns true if the cell is between -0.1 and 0.1."""
       return -0.1 < cell < 0.1
    equator_constraint = iris.Constraint(grid_latitude=near_zero)

Often you will see this construct in shorthand using a lambda function definition:

    equator_constraint = iris.Constraint(grid_latitude=lambda cell: -0.1 < cell < 0.1)

The extract method could be applied again to the equator_slice cube to get a further subset.

For example to get a height of 9000 metres at the equator the following line extends the previous example:

    equator_height_9km_slice = equator_slice.extract(iris.Constraint(height=9000))
    print(equator_height_9km_slice)

The two steps required to get height of 9000 m at the equator can be simplified into a single constraint:

    equator_height_9km_slice = cube.extract(iris.Constraint(grid_latitude=0, height=9000))
    print(equator_height_9km_slice)

Alternatively, constraints can be combined using &:

    cube = iris.load_cube(filename, 'electron density')
    equator_constraint = iris.Constraint(grid_latitude=0)
    height_constraint = iris.Constraint(height=9000)
    equator_height_9km_slice = cube.extract(equator_constraint & height_constraint)

Note

Whilst & is supported, the | that might reasonably be expected is not. Explanation as to why is in the iris.Constraint reference documentation.

For an example of constraining to multiple ranges of the same coordinate to generate one cube, see the iris.Constraint reference documentation.

A common requirement is to limit the value of a coordinate to a specific range, this can be achieved by passing the constraint a function:

    def below_9km(cell):
        # return True or False as to whether the cell in question should be kept
        return cell <= 9000

    cube = iris.load_cube(filename, 'electron density')
    height_below_9km = iris.Constraint(height=below_9km)
    below_9km_slice = cube.extract(height_below_9km)

As we saw in Loading Iris Cubes the result of iris.load() is a CubeList. The extract method also exists on a CubeList and behaves in exactly the same way as loading with constraints:


```python
import iris
air_temp_and_fp_6 = iris.Constraint('air_potential_temperature', forecast_period=6)
level_10 = iris.Constraint(model_level_number=10)
filename = iris.sample_data_path('uk_hires.pp')
cubes = iris.load(filename).extract(air_temp_and_fp_6 & level_10)
print(cubes)
print(cubes[0])
```

    0: air_potential_temperature / (K)     (grid_latitude: 204; grid_longitude: 187)
    air_potential_temperature / (K)     (grid_latitude: 204; grid_longitude: 187)
        Dimension coordinates:
            grid_latitude                             x                    -
            grid_longitude                            -                    x
        Auxiliary coordinates:
            surface_altitude                          x                    x
        Derived coordinates:
            altitude                                  x                    x
        Scalar coordinates:
            forecast_period             6.0 hours
            forecast_reference_time     2009-11-19 04:00:00
            level_height                395.0 m, bound=(360.0, 433.3332) m
            model_level_number          10
            sigma                       0.9549927, bound=(0.9589389, 0.95068014)
            time                        2009-11-19 10:00:00
        Attributes:
            STASH                       m01s00i004
            source                      'Data from Met Office Unified Model'
            um_version                  '7.3'
    

### Constraining on Time

Iris follows NetCDF-CF rules in representing time coordinate values as normalised, purely numeric, values which are normalised by the calendar specified in the coordinate’s units (e.g. “days since 1970-01-01”). However, when constraining by time we usually want to test calendar-related aspects such as hours of the day or months of the year, so Iris provides special features to facilitate this.

Firstly, when Iris evaluates iris.Constraint expressions, it will convert time-coordinate values (points and bounds) from numbers into datetime-like objects for ease of calendar-based testing.


```python
filename = iris.sample_data_path('uk_hires.pp')
cube_all = iris.load_cube(filename, 'air_potential_temperature')
print('All times :\n' + str(cube_all.coord('time')))
# Define a function which accepts a datetime as its argument (this is simplified in later examples).
hour_11 = iris.Constraint(time=lambda cell: cell.point.hour == 11)
cube_11 = cube_all.extract(hour_11)
print('Selected times :\n' + str(cube_11.coord('time')))
```

    All times :
    DimCoord :  time / (hours since 1970-01-01 00:00:00, standard calendar)
        points: [2009-11-19 10:00:00, 2009-11-19 11:00:00, 2009-11-19 12:00:00]
        shape: (3,)
        dtype: float64
        standard_name: 'time'
    Selected times :
    DimCoord :  time / (hours since 1970-01-01 00:00:00, standard calendar)
        points: [2009-11-19 11:00:00]
        shape: (1,)
        dtype: float64
        standard_name: 'time'
    

Secondly, the iris.time module provides flexible time comparison facilities. An iris.time.PartialDateTime object can be compared to objects such as datetime.datetime instances, and this comparison will then test only those ‘aspects’ which the PartialDateTime instance defines:

    import datetime
    from iris.time import PartialDateTime
    dt = datetime.datetime(2011, 3, 7)
    print(dt > PartialDateTime(year=2010, month=6))
True
    print(dt > PartialDateTime(month=6))
False

These two facilities can be combined to provide straightforward calendar-based time selections when loading or extracting data.

The previous constraint example can now be written as:


```python
the_11th_hour = iris.Constraint(time=iris.time.PartialDateTime(hour=11))
print(iris.load_cube(
    iris.sample_data_path('uk_hires.pp'),
   'air_potential_temperature' & the_11th_hour).coord('time'))
```

    DimCoord :  time / (hours since 1970-01-01 00:00:00, standard calendar)
        points: [2009-11-19 11:00:00]
        shape: (1,)
        dtype: float64
        standard_name: 'time'
    


```python
import iris
filename = iris.sample_data_path('uk_hires.pp')
cubes = iris.load(filename)
# get the first cube (list indexing is 0 based)
air_potential_temperature = cubes[0]
print(air_potential_temperature.coord('time'))
```

    DimCoord :  time / (hours since 1970-01-01 00:00:00, standard calendar)
        points: [2009-11-19 10:00:00, 2009-11-19 11:00:00, 2009-11-19 12:00:00]
        shape: (3,)
        dtype: float64
        standard_name: 'time'
    


```python
print(cube_all)
```

    air_potential_temperature / (K)     (time: 3; model_level_number: 7; grid_latitude: 204; grid_longitude: 187)
        Dimension coordinates:
            time                             x                      -                 -                    -
            model_level_number               -                      x                 -                    -
            grid_latitude                    -                      -                 x                    -
            grid_longitude                   -                      -                 -                    x
        Auxiliary coordinates:
            forecast_period                  x                      -                 -                    -
            level_height                     -                      x                 -                    -
            sigma                            -                      x                 -                    -
            surface_altitude                 -                      -                 x                    x
        Derived coordinates:
            altitude                         -                      x                 x                    x
        Scalar coordinates:
            forecast_reference_time     2009-11-19 04:00:00
        Attributes:
            STASH                       m01s00i004
            source                      'Data from Met Office Unified Model'
            um_version                  '7.3'
    

Given two dates in datetime format, we can select all points between them. Instead of constraining at loaded time, we already have the time coord so we constrain that coord using 

    iris.cube.Cube.extract


```python
d1 = datetime.datetime.strptime('20090715T0000Z', '%Y%m%dT%H%MZ')
d2 = datetime.datetime.strptime('20100825T0000Z', '%Y%m%dT%H%MZ')
st_swithuns_daterange_07 = iris.Constraint(
    time=lambda cell: d1 <= cell.point < d2)
within_st_swithuns_07 = air_potential_temperature.extract(st_swithuns_daterange_07)
print(within_st_swithuns_07.coord('time'))
```

    DimCoord :  time / (hours since 1970-01-01 00:00:00, standard calendar)
        points: [2009-11-19 10:00:00, 2009-11-19 11:00:00, 2009-11-19 12:00:00]
        shape: (3,)
        dtype: float64
        standard_name: 'time'
    

Alternatively, we may rewrite this using iris.time.PartialDateTime objects.

    pdt1 = PartialDateTime(year=2007, month=7, day=15)
    pdt2 = PartialDateTime(year=2007, month=8, day=25)
    st_swithuns_daterange_07 = iris.Constraint(
        time=lambda cell: pdt1 <= cell.point < pdt2)
    within_st_swithuns_07 = air_potential_temperature.extract(st_swithuns_daterange_07)
    print(within_st_swithuns_07.coord('time'))

A more complex example might require selecting points over an annually repeating date range. We can select points within a certain part of the year, in this case between the 15th of July through to the 25th of August. By making use of PartialDateTime this becomes simple:


```python
st_swithuns_daterange = iris.Constraint(
    time=lambda cell: PartialDateTime(month=7, day=15) <= cell.point < PartialDateTime(month=8, day=25))
within_st_swithuns = air_potential_temperature.extract(st_swithuns_daterange)
# Note: using summary(max_values) to show more of the points
print(within_st_swithuns.coord('time').summary(max_values=100))
```

### Cube Iteration

It is not possible to directly iterate over an Iris cube. That is, you cannot use code such as for x in cube:. However, you can iterate over cube slices, as this section details.

A useful way of dealing with a Cube in its entirety is by iterating over its layers or slices. For example, to deal with a 3 dimensional cube (z,y,x) you could iterate over all 2 dimensional slices in y and x which make up the full 3d cube.:

    import iris
    filename = iris.sample_data_path('hybrid_height.nc')
    cube = iris.load_cube(filename)
    print(cube)
    for yx_slice in cube.slices(['grid_latitude', 'grid_longitude']):
       print(repr(yx_slice))

As the original cube had the shape (15, 100, 100) there were 15 latitude longitude slices and hence the line print(repr(yx_slice)) was run 15 times.

This method can handle n-dimensional slices by providing more or fewer coordinate names in the list to slices:

    import iris
    filename = iris.sample_data_path('hybrid_height.nc')
    cube = iris.load_cube(filename)
    print(cube)
    for i, x_slice in enumerate(cube.slices(['grid_longitude'])):
       print(i, repr(x_slice))

The Python function enumerate() is used in this example to provide an incrementing variable i which is printed with the summary of each cube slice. Note that there were 1500 1d longitude cubes as a result of slicing the 3 dimensional cube (15, 100, 100) by longitude (i starts at 0 and 1500 = 15 * 100).

    Hint

It is often useful to get a single 2d slice from a multidimensional cube in order to develop a 2d plot function, for example. This can be achieved by using the next() function on the result of slices:

    first_slice = next(cube.slices(['grid_latitude', 'grid_longitude']))

Once the your code can handle a 2d slice, it is then an easy step to loop over all 2d slices within the bigger cube using the slices method.

### Cube Indexing
In the same way that you would expect a numeric multidimensional array to be indexed to take a subset of your original array, you can index a Cube for the same purpose.


```python
import iris
filename = iris.sample_data_path('hybrid_height.nc')
cube = iris.load_cube(filename)

print(cube)

# get the first element of the first dimension (+ every other dimension)
print(cube[0])

# get the last element of the first dimension (+ every other dimension)
print(cube[-1])

# get the first 4 elements of the first dimension (+ every other dimension)
print(cube[0:4])

# Get the first element of the first and third dimension (+ every other dimension)
print(cube[0, :, 0])

# Get the second element of the first dimension and all of the second dimension
# in reverse, by steps of two.
print(cube[1, ::-2])
```

    C:\Users\User\AppData\Local\Temp\ipykernel_14572\3887445638.py:3: FutureWarning: Ignoring a datum in netCDF load for consistency with existing behaviour. In a future version of Iris, this datum will be applied. To apply the datum when loading, use the iris.FUTURE.datum_support flag.
      cube = iris.load_cube(filename)
    


    ---------------------------------------------------------------------------

    MergeError                                Traceback (most recent call last)

    File ~\anaconda3\Lib\site-packages\iris\__init__.py:358, in load_cube(uris, constraint, callback)
        357 try:
    --> 358     cube = cubes.merge_cube()
        359 except iris.exceptions.MergeError as e:
    

    File ~\anaconda3\Lib\site-packages\iris\cube.py:439, in CubeList.merge_cube(self)
        438 for cube in self[1:]:
    --> 439     proto_cube.register(cube, error_on_mismatch=True)
        441 # Extract the merged cube from the ProtoCube.
    

    File ~\anaconda3\Lib\site-packages\iris\_merge.py:1358, in ProtoCube.register(self, cube, error_on_mismatch)
       1357 other = self._build_signature(cube)
    -> 1358 match = cube_signature.match(other, error_on_mismatch)
       1359 if match:
    

    File ~\anaconda3\Lib\site-packages\iris\_merge.py:465, in _CubeSignature.match(self, other, error_on_mismatch)
        464 if error_on_mismatch and not match:
    --> 465     raise iris.exceptions.MergeError(msgs)
        466 return match
    

    MergeError: failed to merge into a single cube.
      cube.standard_name differs: 'air_potential_temperature' != 'surface_altitude'
      cube.var_name differs: 'air_potential_temperature' != 'surface_altitude'
      cube.units differs: Unit('K') != Unit('m')
      cube.attributes values differ for keys: 'STASH'
      cube.shape differs: (15, 100, 100) != (100, 100)

    
    During handling of the above exception, another exception occurred:
    

    ConstraintMismatchError                   Traceback (most recent call last)

    Cell In[24], line 3
          1 import iris
          2 filename = iris.sample_data_path('hybrid_height.nc')
    ----> 3 cube = iris.load_cube(filename)
          5 print(cube)
          7 # get the first element of the first dimension (+ every other dimension)
    

    File ~\anaconda3\Lib\site-packages\iris\__init__.py:360, in load_cube(uris, constraint, callback)
        358     cube = cubes.merge_cube()
        359 except iris.exceptions.MergeError as e:
    --> 360     raise iris.exceptions.ConstraintMismatchError(str(e))
        361 except ValueError:
        362     raise iris.exceptions.ConstraintMismatchError("no cubes found")
    

    ConstraintMismatchError: failed to merge into a single cube.
      cube.standard_name differs: 'air_potential_temperature' != 'surface_altitude'
      cube.var_name differs: 'air_potential_temperature' != 'surface_altitude'
      cube.units differs: Unit('K') != Unit('m')
      cube.attributes values differ for keys: 'STASH'
      cube.shape differs: (15, 100, 100) != (100, 100)


# Real and Lazy Data

We have seen in the Iris Data Structures section of the user guide that Iris cubes contain data and metadata about a phenomenon. The data element of a cube is always an array, but the array may be either “real” or “lazy”.

In this section of the user guide we will look specifically at the concepts of real and lazy data as they apply to the cube and other data structures in Iris.
### What is Real and Lazy Data?

In Iris, we use the term real data to describe data arrays that are loaded into memory. Real data is typically provided as a NumPy array, which has a shape and data type that are used to describe the array’s data points. Each data point takes up a small amount of memory, which means large NumPy arrays can take up a large amount of memory.

Conversely, we use the term lazy data to describe data that is not loaded into memory. (This is sometimes also referred to as deferred data.) In Iris, lazy data is provided as a dask array. A dask array also has a shape and data type but the dask array’s data points remain on disk and only loaded into memory in small chunks when absolutely necessary. This has key performance benefits for handling large amounts of data, where both calculation time and storage requirements can be significantly reduced.

In Iris, when actual data values are needed from a lazy data array, it is ‘realised’ : this means that all the actual values are read in from the file, and a ‘real’ (i.e. numpy) array replaces the lazy array within the Iris object.

Following realisation, the Iris object just contains the actual (‘real’) data, so the time cost of reading all the data is not incurred again. From here on, access to the data is fast, but it now occupies its full memory space.

In particular, any direct reference to a cube.data will realise the cube data content : any lazy content is lost as the data is read from file, and the cube content is replaced with a real array. This is also referred to simply as “touching” the data.

You can check whether a cube has real data or lazy data by using the method has_lazy_data(). For example:

    cube = iris.load_cube(iris.sample_data_path('air_temp.pp'))
    cube.has_lazy_data()
True
    # Realise the lazy data.

    cube.data

    cube.has_lazy_data()
False

### Benefits

The primary advantage of using lazy data is that it enables out-of-core processing; that is, the loading and manipulating of datasets without loading the full data into memory.

There are two key benefits from this :

Firstly, the result of a calculation on a large dataset often occupies much less storage space than the source data – such as for instance a maximum data value calculated over a large number of datafiles. In these cases the result can be computed in sections, without ever requiring the entire source dataset to be loaded, thus drastically reducing memory footprint. This strategy of task division can also enable reduced execution time through the effective use of parallel processing capabilities.

Secondly, it is often simply convenient to form a calculation on a large dataset, of which only a certain portion is required at any one time – for example, plotting individual timesteps from a large sequence. In such cases, a required portion can be extracted and realised without calculating the entire result.
### When Does My Data Become Real?

Certain operations, such as cube indexing and statistics, can be performed in a lazy fashion, producing a ‘lazy’ result from a lazy input, so that no realisation immediately occurs. However other operations, such as plotting or printing data values, will always trigger the ‘realisation’ of data.

When you load a dataset using Iris the data array will almost always initially be a lazy array. This section details some operations that will realise lazy data as well as some operations that will maintain lazy data. We use the term realise to mean converting lazy data into real data.

Most operations on data arrays can be run equivalently on both real and lazy data. If the data array is real then the operation will be run on the data array immediately. The results of the operation will be available as soon as processing is completed. If the data array is lazy then the operation will be deferred and the data array will remain lazy until you request the result (such as when you read from cube.data):

    cube = iris.load_cube(iris.sample_data_path('air_temp.pp'))
    cube.has_lazy_data()
True
    
    cube += 5
    
    cube.has_lazy_data()
True

The process by which the operation is deferred until the result is requested is referred to as lazy evaluation.

Certain operations, including regridding and plotting, can only be run on real data. Calling such operations on lazy data will automatically realise your lazy data.

You can also realise (and so load into memory) your cube’s lazy data if you ‘touch’ the data. To ‘touch’ the data means directly accessing the data by calling cube.data, as in the previous example.
### Core Data

Cubes have the concept of “core data”. This returns the cube’s data in its current state:

    If a cube has lazy data, calling the cube’s core_data() method will return the cube’s lazy dask array. Calling the cube’s core_data() method will never realise the cube’s data.

    If a cube has real data, calling the cube’s core_data() method will return the cube’s real NumPy array.

For example:


```python
cube = iris.load_cube(iris.sample_data_path('air_temp.pp'))
cube.has_lazy_data()

the_data = cube.core_data()
type(the_data)
cube.has_lazy_data()

cube.data
the_data = cube.core_data()
type(the_data)
cube.has_lazy_data()
```




    False



### Coordinates

In the same way that Iris cubes contain a data array, Iris coordinates contain a points array and an optional bounds array. Coordinate points and bounds arrays can also be real or lazy:

    A DimCoord will only ever have real points and bounds arrays because of monotonicity checks that realise lazy arrays.

    An AuxCoord can have real or lazy points and bounds.

    An AuxCoordFactory (or derived coordinate) can have real or lazy points and bounds. If all of the AuxCoord instances used to construct the derived coordinate have real points and bounds then the derived coordinate will have real points and bounds, otherwise the derived coordinate will have lazy points and bounds.

Iris cubes and coordinates have very similar interfaces, which extends to accessing coordinates’ lazy points and bounds:


```python
cube = iris.load_cube(iris.sample_data_path('orca2_votemper.nc'),'votemper')

dim_coord = cube.coord('depth')
print(dim_coord.has_lazy_points())
print(dim_coord.has_bounds())
print(dim_coord.has_lazy_bounds())

aux_coord = cube.coord('longitude')
print(aux_coord.has_lazy_points())
print(aux_coord.has_bounds())
print(aux_coord.has_lazy_bounds())

points = aux_coord.points
print(aux_coord.has_lazy_points())
print(aux_coord.has_lazy_bounds())

cube2 = iris.load_cube(iris.sample_data_path('hybrid_height.nc'), 'air_potential_temperature')
derived_coord = cube2.coord('altitude')
print(derived_coord.has_lazy_points())
print(derived_coord.has_bounds())
print(derived_coord.has_lazy_bounds())
```

    False
    True
    False
    True
    True
    True
    False
    True
    True
    True
    True
    

    C:\Users\User\AppData\Local\Temp\ipykernel_14572\503982487.py:17: FutureWarning: Ignoring a datum in netCDF load for consistency with existing behaviour. In a future version of Iris, this datum will be applied. To apply the datum when loading, use the iris.FUTURE.datum_support flag.
      cube2 = iris.load_cube(iris.sample_data_path('hybrid_height.nc'), 'air_potential_temperature')
    

# Plotting a Cube
Iris utilises the power of Python’s Matplotlib package in order to generate high quality, production ready 1D and 2D plots. The functionality of the Matplotlib pyplot module has been extended within Iris to facilitate easy visualisation of a cube’s data.

### Saving a Plot

The matplotlib.pyplot.savefig() function is similar to plt.show() in that they are both non-interactive visualisation modes. As you might expect, plt.savefig saves your figure as an image:

    import matplotlib.pyplot as plt
    plt.plot([1, 2, 2.5])
    plt.savefig('plot123.png')

The filename extension passed to the matplotlib.pyplot.savefig() function can be used to control the output file format of the plot (keywords can also be used to control this and other aspects, see matplotlib.pyplot.savefig()).

Some of the formats which are supported by plt.savefig: png (lossless), eps, pdf, svg  (not jpeg).

### Iris Cube Plotting

The Iris modules iris.quickplot and iris.plot extend the Matplotlib pyplot interface by implementing thin wrapper functions. These wrapper functions simply bridge the gap between an Iris cube and the data expected by standard Matplotlib pyplot functions. This means that all Matplotlib pyplot functionality, including keyword options, are still available through the Iris plotting wrapper functions.

As a rule of thumb:

    if you wish to do a visualisation with a cube, use iris.plot or iris.quickplot.

    if you wish to show, save or manipulate any visualisation, including ones created with Iris, use matplotlib.pyplot.

    if you wish to create a non cube visualisation, also use matplotlib.pyplot.

The iris.quickplot module is exactly the same as the iris.plot module, except that quickplot will add a title, x and y labels and a colorbar where appropriate.

    Note

In all subsequent examples the matplotlib.pyplot, iris.plot and iris.quickplot modules are imported as plt, iplt and qplt respectively in order to make the code more readable. This is equivalent to:

    import matplotlib.pyplot as plt
    import iris.plot as iplt
    import iris.quickplot as qplt

### Plotting 1-Dimensional Cubes
The simplest 1D plot is achieved with the iris.plot.plot() function. The syntax is very similar to that which you would provide to Matplotlib’s equivalent matplotlib.pyplot.plot() and indeed all of the keyword arguments are equivalent:


```python
"""Simple 1D plot using iris.plot.plot()."""

import matplotlib.pyplot as plt

import iris
import iris.plot as iplt

fname = iris.sample_data_path("air_temp.pp")
temperature = iris.load_cube(fname)

# Take a 1d slice using array style indexing.
temperature_1d = temperature[5, :]

iplt.plot(temperature_1d)

plt.show()
```


    
![png](output_47_0.png)
    


    Note

Axis labels and a plot title can be added using the plt.title(), plt.xlabel() and plt.ylabel() functions.

As well as providing simple Matplotlib wrappers, Iris also has a iris.quickplot module, which adds extra cube based metadata to a plot. For example, the previous plot can be improved quickly by replacing iris.plot with iris.quickplot:


```python
"""Simple 1D plot using iris.quickplot.plot()."""

import matplotlib.pyplot as plt

import iris
import iris.quickplot as qplt

fname = iris.sample_data_path("air_temp.pp")
temperature = iris.load_cube(fname)

# Take a 1d slice using array style indexing.
temperature_1d = temperature[5, :]

qplt.plot(temperature_1d)

plt.show()
```


    
![png](output_49_0.png)
    


### Multi-Line Plot
A multi-lined (or over-plotted) plot, with a legend, can be achieved easily by calling iris.plot.plot() or iris.quickplot.plot() consecutively and providing the label keyword to identify it. Once all of the lines have been added the matplotlib.pyplot.legend() function can be called to indicate that a legend is desired:


```python
"""
Multi-Line Temperature Profile Plot
===================================

"""  # noqa: D205, D212, D400

import matplotlib.pyplot as plt

import iris
import iris.plot as iplt
import iris.quickplot as qplt


def main():
    fname = iris.sample_data_path("air_temp.pp")

    # Load exactly one cube from the given file.
    temperature = iris.load_cube(fname)

    # We only want a small number of latitudes, so filter some out
    # using "extract".
    temperature = temperature.extract(
        iris.Constraint(latitude=lambda cell: 68 <= cell < 78)
    )

    for cube in temperature.slices("longitude"):
        # Create a string label to identify this cube (i.e. latitude: value).
        cube_label = "latitude: %s" % cube.coord("latitude").points[0]

        # Plot the cube, and associate it with a label.
        qplt.plot(cube, label=cube_label)

    # Add the legend with 2 columns.
    plt.legend(ncol=2)

    # Put a grid on the plot.
    plt.grid(True)

    # Tell matplotlib not to extend the plot axes range to nicely
    # rounded numbers.
    plt.axis("tight")

    # Finally, show it.
    iplt.show()


if __name__ == "__main__":
    main()
```


    
![png](output_51_0.png)
    


This example of consecutive qplt.plot calls coupled with the Cube.slices() method on a cube shows the temperature at some latitude cross-sections.

    Note

    The previous example uses the if __name__ == "__main__" style to run the desired code if and only if the script is run from the command line.

    This is a good habit to get into when writing scripts in Python as it means that any useful functions or variables defined within the script can be imported into other scripts without running all of the code and thus creating an unwanted plot. This is discussed in more detail at https://effbot.org/pyfaq/tutor-what-is-if-name-main-for.htm.

Whenever a 2D plot is created using an iris.coord_systems.CoordSystem, a cartopy GeoAxes instance is created, which can be accessed with the matplotlib.pyplot.gca() function.

Given the current map, you can draw gridlines and coastlines amongst other things.

### Cube Contour
A simple contour plot of a cube can be created with either the iris.plot.contour() or iris.quickplot.contour() functions:


```python
"""Simple contour plot of a cube.

Can use iris.plot.contour() or iris.quicplot.contour().

"""
import matplotlib.pyplot as plt

import iris
import iris.quickplot as qplt

fname = iris.sample_data_path("air_temp.pp")
temperature_cube = iris.load_cube(fname)

# Add a contour, and put the result in a variable called contour.
contour = qplt.contour(temperature_cube)

# Add coastlines to the map created by contour.
plt.gca().coastlines()

# Add contour labels based on the contour we have just created.
plt.clabel(contour, inline=False)

plt.show()
```


    
![png](output_53_0.png)
    


### Cube Filled Contour
Similarly a filled contour plot of a cube can be created with the iris.plot.contourf() or iris.quickplot.contourf() functions:


```python
"""Simple filled contour plot of a cube.

Can use iris.plot.contour() or iris.quickplot.contour().

"""
import matplotlib.pyplot as plt

import iris
import iris.quickplot as qplt

fname = iris.sample_data_path("air_temp.pp")
temperature_cube = iris.load_cube(fname)

# Draw the contour with 25 levels.
qplt.contourf(temperature_cube, 25)

# Add coastlines to the map created by contourf.
plt.gca().coastlines()

plt.show()
```


    
![png](output_55_0.png)
    


### Cube Block Plot

In some situations the underlying coordinates are better represented with a continuous bounded coordinate, in which case a “block” plot may be more appropriate. Continuous block plots can be achieved with either iris.plot.pcolormesh() or iris.quickplot.pcolormesh().

    Note

    If the cube’s coordinates do not have bounds, iris.plot.pcolormesh() and iris.quickplot.pcolormesh() will attempt to guess suitable values based on their points (see also iris.coords.Coord.guess_bounds()).


```python
"""Cube block plot using using iris.plot.pcolormesh()."""

import matplotlib.pyplot as plt

import iris
import iris.quickplot as qplt

# Load the data for a single value of model level number.
fname = iris.sample_data_path("hybrid_height.nc")
temperature_cube = iris.load_cube(fname, iris.Constraint(model_level_number=1))

# Draw the block plot.
qplt.pcolormesh(temperature_cube)

plt.show()
```

    C:\Users\User\AppData\Local\Temp\ipykernel_14572\964729242.py:10: FutureWarning: Ignoring a datum in netCDF load for consistency with existing behaviour. In a future version of Iris, this datum will be applied. To apply the datum when loading, use the iris.FUTURE.datum_support flag.
      temperature_cube = iris.load_cube(fname, iris.Constraint(model_level_number=1))
    


    
![png](output_57_1.png)
    


### Available Brewer Schemes - for plot colour palette

The following subset of Brewer palettes found at colorbrewer2.org are available within Iris.
    https://scitools-iris.readthedocs.io/en/latest/userguide/plotting_a_cube.html

### Plotting With Brewer
To plot a cube using a Brewer colour palette, simply select one of the Iris registered Brewer colour palettes and plot the cube as normal. The Brewer palettes become available once iris.plot or iris.quickplot are imported.


```python
"""Plot a cube with a Brewer colour palette using iris.quickplot.contourf()."""

import matplotlib.cm as mpl_cm
import matplotlib.pyplot as plt

import iris
import iris.quickplot as qplt

fname = iris.sample_data_path("air_temp.pp")
temperature_cube = iris.load_cube(fname)

# Load a Cynthia Brewer palette.
brewer_cmap = mpl_cm.get_cmap("brewer_OrRd_09")

# Draw the contours, with n-levels set for the map colours (9).
# NOTE: needed as the map is non-interpolated, but matplotlib does not provide
# any special behaviour for these.
qplt.contourf(temperature_cube, brewer_cmap.N, cmap=brewer_cmap)

# Add coastlines to the map created by contourf.
plt.gca().coastlines()

plt.show()
```

    C:\Users\User\AppData\Local\Temp\ipykernel_26848\2062572628.py:13: MatplotlibDeprecationWarning: The get_cmap function was deprecated in Matplotlib 3.7 and will be removed two minor releases later. Use ``matplotlib.colormaps[name]`` or ``matplotlib.colormaps.get_cmap(obj)`` instead.
      brewer_cmap = mpl_cm.get_cmap("brewer_OrRd_09")
    


    
![png](output_59_1.png)
    


# MIKE:  having a go at loading and charting data (not in the "sample data set") from the met office

### Calculate global mean SST time series

The data are in NetCDF format, which is a standard data format for climate data. Furthermore, the data files are CF compliant which means that the metadata in the files is in a standardised format. The structure of the data files is described in more detail in Section 3. Some example code for reading and processing the data is found in Section 4. The gridded data are stored in a 3-dimensional array, with dimensions of time x longitude x latitude. There are 72 longitude points and 36 latitude points. The 72 longitude points represent 5◦ grid cells with centres running from −177.5◦E to +177.5◦E. The 36 latitude points represent grid cells with centres running from −87.5◦N to +87.5◦N.

Read data and calculate a global mean SST anomaly series from 1850 to present using the Iris package in Python.


```python
import iris
import numpy as np
import matplotlib.pyplot as plt
import iris.analysis.cartography
# anoms = iris.load_cube('HadSST.4.0.1.0_median.nc')
# https://www.metoffice.gov.uk/hadobs/hadsst4/data/netcdf/HadSST.4.0.1.0_median.nc')
anoms = iris.load_cube("C:/Users/User/Documents/Mike/2023_job_applications/python_training_2023/HadSST.4.0.1.0_median.nc")
grid_areas = iris.analysis.cartography.area_weights ( anoms )
#timeseries = anoms.collapsed (['longitude','latitude'] ,
#                                iris.analysis.MEAN , weights = grid_areas )
#plt.plot(timeseries)
#plt.show()
```

    C:\Users\User\anaconda3\Lib\site-packages\iris\analysis\cartography.py:413: UserWarning: Using DEFAULT_SPHERICAL_EARTH_RADIUS.
      warnings.warn("Using DEFAULT_SPHERICAL_EARTH_RADIUS.")
    


```python
print(anoms)
```

    sea_water_temperature_anomaly / (K) (time: 2088; latitude: 36; longitude: 72)
        Dimension coordinates:
            time                             x               -              -
            latitude                         -               x              -
            longitude                        -               -              x
        Cell methods:
            0                           area: mean (interval: 5.0 degrees_north 5.0 degrees_east)
            1                           time: mean (interval: 1 month)
        Attributes:
            Conventions                 'CF-1.7'
            comment                     ''
            history                     'Converted to netcdf today'
            institution                 'Met Office'
            reference                   'Kennedy et al. (2019), https://www.metoffice.gov.uk/hadobs/hadsst4'
            source                      'surface observation'
            title                       'Ensemble-median sea-surface temperature anomalies from the HadSST.4.0.1.0 ...'
            version                     'HadSST.4.0.1.0'
    


```python
print(anoms.summary)
```

    <bound method Cube.summary of <iris 'Cube' of sea_water_temperature_anomaly / (K) (time: 2088; latitude: 36; longitude: 72)>>
    


```python
print(anoms.units) # Kelvin.
#print(repr(anoms))
#print(type(anoms))
```

    K
    


```python
for coord in anoms.coords():
    print(coord.name())
```

    time
    latitude
    longitude
    


```python
# Find the values of a cell so I can get a time series plot for 1 cell.

# To get an individual coordinate given its name, the Cube.coord method can be used:

coord = anoms.coord('latitude')
print('latitude')
print(type(coord))

# Additionally every coordinate can provide its points and bounds numpy array. If the coordinate has no bounds None will be returned:

print(coord.points)

# now for longitude:

coord = anoms.coord('longitude')
print('longitude')
print(coord.points)

# now for time:

coord = anoms.coord('time')
print('time')
print(coord.points)
print(coord.units)
```

    latitude
    <class 'iris.coords.DimCoord'>
    [-87.5 -82.5 -77.5 -72.5 -67.5 -62.5 -57.5 -52.5 -47.5 -42.5 -37.5 -32.5
     -27.5 -22.5 -17.5 -12.5  -7.5  -2.5   2.5   7.5  12.5  17.5  22.5  27.5
      32.5  37.5  42.5  47.5  52.5  57.5  62.5  67.5  72.5  77.5  82.5  87.5]
    longitude
    [-177.5 -172.5 -167.5 -162.5 -157.5 -152.5 -147.5 -142.5 -137.5 -132.5
     -127.5 -122.5 -117.5 -112.5 -107.5 -102.5  -97.5  -92.5  -87.5  -82.5
      -77.5  -72.5  -67.5  -62.5  -57.5  -52.5  -47.5  -42.5  -37.5  -32.5
      -27.5  -22.5  -17.5  -12.5   -7.5   -2.5    2.5    7.5   12.5   17.5
       22.5   27.5   32.5   37.5   42.5   47.5   52.5   57.5   62.5   67.5
       72.5   77.5   82.5   87.5   92.5   97.5  102.5  107.5  112.5  117.5
      122.5  127.5  132.5  137.5  142.5  147.5  152.5  157.5  162.5  167.5
      172.5  177.5]
    time
    [1.55000e+01 4.50000e+01 7.45000e+01 ... 6.34755e+04 6.35060e+04
     6.35365e+04]
    days since 1850-01-01T00:00:00Z
    


```python
print(coord.points)

```

    [-87.5 -82.5 -77.5 -72.5 -67.5 -62.5 -57.5 -52.5 -47.5 -42.5 -37.5 -32.5
     -27.5 -22.5 -17.5 -12.5  -7.5  -2.5   2.5   7.5  12.5  17.5  22.5  27.5
      32.5  37.5  42.5  47.5  52.5  57.5  62.5  67.5  72.5  77.5  82.5  87.5]
    


```python
# Now I know the coord value I can subset to a small section.

equator = anoms.extract(iris.Constraint(latitude=lambda cell: -30 < cell < 30, longitude=lambda cell: 20 < cell < 40))
mean = equator_anoms.collapsed(["latitude", "longitude"], iris.analysis.MEAN)
print(mean)
```


    ---------------------------------------------------------------------------

    CoordinateCollapseError                   Traceback (most recent call last)

    Cell In[26], line 4
          1 # Now I know the coord value I can subset to a small section.
          3 equator = anoms.extract(iris.Constraint(latitude=lambda cell: -30 < cell < 30, longitude=lambda cell: 20 < cell < 40))
    ----> 4 mean = equator_anoms.collapsed(["latitude", "longitude"], iris.analysis.MEAN)
          5 print(mean)
    

    File ~\anaconda3\Lib\site-packages\iris\cube.py:3888, in Cube.collapsed(self, coords, aggregator, **kwargs)
       3883 if not dims_to_collapse:
       3884     msg = (
       3885         "Cannot collapse a dimension which does not describe any "
       3886         "data."
       3887     )
    -> 3888     raise iris.exceptions.CoordinateCollapseError(msg)
       3890 untouched_dims = set(range(self.ndim)) - set(dims_to_collapse)
       3892 collapsed_cube = iris.util._strip_metadata_from_dims(
       3893     self, dims_to_collapse
       3894 )
    

    CoordinateCollapseError: Cannot collapse a dimension which does not describe any data.



```python
PLAN: Extract 1 "slice" from the anoms cube and plot it to check it contains data.
```


```python
# Find the date time points.

print('All times :\n' + str(anoms.coord('time'))) # first one is 1850-01-16 12:00:00
```

    All times :
    DimCoord :  time / (days since 1850-01-01T00:00:00Z, standard calendar)
        points: [
            1850-01-16 12:00:00, 1850-02-15 00:00:00, ...,
            2023-11-16 00:00:00, 2023-12-16 12:00:00]
        bounds: [
            [1850-01-01 00:00:00, 1850-02-01 00:00:00],
            [1850-02-01 00:00:00, 1850-03-01 00:00:00],
            ...,
            [2023-11-01 00:00:00, 2023-12-01 00:00:00],
            [2023-12-01 00:00:00, 2024-01-01 00:00:00]]
        shape: (2088,)  bounds(2088, 2)
        dtype: float64
        standard_name: 'time'
        long_name: 'time'
        var_name: 'time'
    


```python
pdt1 = PartialDateTime(year=1850, month=1, day=14)
pdt2 = PartialDateTime(year=1850, month=1, day=18)
first_daterange = iris.Constraint(
    time=lambda cell: pdt1 <= cell.point < pdt2)
first_slice = anoms.extract(first_daterange) # extract the first slice using date constraints.
print(first_slice)
```

    sea_water_temperature_anomaly / (K) (latitude: 36; longitude: 72)
        Dimension coordinates:
            latitude                             x              -
            longitude                            -              x
        Scalar coordinates:
            time                        1850-01-16 12:00:00, bound=(1850-01-01 00:00:00, 1850-02-01 00:00:00)
        Cell methods:
            0                           area: mean (interval: 5.0 degrees_north 5.0 degrees_east)
            1                           time: mean (interval: 1 month)
        Attributes:
            Conventions                 'CF-1.7'
            comment                     ''
            history                     'Converted to netcdf today'
            institution                 'Met Office'
            reference                   'Kennedy et al. (2019), https://www.metoffice.gov.uk/hadobs/hadsst4'
            source                      'surface observation'
            title                       'Ensemble-median sea-surface temperature anomalies from the HadSST.4.0.1.0 ...'
            version                     'HadSST.4.0.1.0'
    


```python
""" Simple filled contour plot of a cube.

Can use iris.plot.contour() or iris.quickplot.contour().

"""
import matplotlib.pyplot as plt

import iris
import iris.quickplot as qplt

# Draw the contour with 25 levels.
qplt.contourf(first_slice, 25)

# Add coastlines to the map created by contourf.
plt.gca().coastlines()

plt.show()
```


    
![png](output_72_0.png)
    



```python
"""Plot a cube with a Brewer colour palette using iris.quickplot.contourf()."""

import matplotlib.cm as mpl_cm
import matplotlib.pyplot as plt

import iris
import iris.quickplot as qplt

# Load a Cynthia Brewer palette.
brewer_cmap = mpl_cm.get_cmap("brewer_OrRd_09")

# Draw the contours, with n-levels set for the map colours (9).
# NOTE: needed as the map is non-interpolated, but matplotlib does not provide
# any special behaviour for these.
qplt.contourf(first_slice, brewer_cmap.N, cmap=brewer_cmap)

# Add coastlines to the map created by contourf.
plt.gca().coastlines()

plt.show()
```

    C:\Users\User\AppData\Local\Temp\ipykernel_26848\665481931.py:10: MatplotlibDeprecationWarning: The get_cmap function was deprecated in Matplotlib 3.7 and will be removed two minor releases later. Use ``matplotlib.colormaps[name]`` or ``matplotlib.colormaps.get_cmap(obj)`` instead.
      brewer_cmap = mpl_cm.get_cmap("brewer_OrRd_09")
    


    
![png](output_73_1.png)
    



```python
# It looks like the only data points are the anomalies - not the temp everywhere. 
# Try plotting the final slice and see if it has v different points populated.

pdt1 = PartialDateTime(year=2023, month=12, day=14)
pdt2 = PartialDateTime(year=2023, month=12, day=18)
last_daterange = iris.Constraint(
    time=lambda cell: pdt1 <= cell.point < pdt2)
last_slice = anoms.extract(last_daterange) # extract the first slice using date constraints.
print(last_slice)
```

    sea_water_temperature_anomaly / (K) (latitude: 36; longitude: 72)
        Dimension coordinates:
            latitude                             x              -
            longitude                            -              x
        Scalar coordinates:
            time                        2023-12-16 12:00:00, bound=(2023-12-01 00:00:00, 2024-01-01 00:00:00)
        Cell methods:
            0                           area: mean (interval: 5.0 degrees_north 5.0 degrees_east)
            1                           time: mean (interval: 1 month)
        Attributes:
            Conventions                 'CF-1.7'
            comment                     ''
            history                     'Converted to netcdf today'
            institution                 'Met Office'
            reference                   'Kennedy et al. (2019), https://www.metoffice.gov.uk/hadobs/hadsst4'
            source                      'surface observation'
            title                       'Ensemble-median sea-surface temperature anomalies from the HadSST.4.0.1.0 ...'
            version                     'HadSST.4.0.1.0'
    


```python
qplt.contourf(last_slice, brewer_cmap.N, cmap=brewer_cmap)

# Add coastlines to the map created by contourf.
plt.gca().coastlines()

plt.show()
```


    
![png](output_75_0.png)
    



    <Figure size 640x480 with 0 Axes>



```python
# Summary code to do the above. Ie load, explore and visualise.
""" Read in Hadley sea surface temperature anomaly data in NetCDF format. It spans 1850 - 2023.
Visualise the latest 2023 anomaly global picture using the Iris package in Python.
"""
import iris
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as mpl_cm
import datetime
from iris.time import PartialDateTime

# https://www.metoffice.gov.uk/hadobs/hadsst4/data/netcdf/HadSST.4.0.1.0_median.nc')
anoms = iris.load_cube("C:/Users/User/Documents/Mike/2023_job_applications/python_training_2023/HadSST.4.0.1.0_median.nc")

print(anoms) # See the cube metadata.

# now get time coordinate information:
coord = anoms.coord('time')
print('time')
print(coord.points)
print(coord.units)

# Find the date time points.

print('All times :\n' + str(anoms.coord('time'))) # first one is 1850-01-16 12:00:00. Last is 2023-12-16 12:00:00.

# Extract the final slice. Use a function to select the slice inbetween 2 dates.

pdt1 = PartialDateTime(year=2023, month=12, day=14)
pdt2 = PartialDateTime(year=2023, month=12, day=18)
last_daterange = iris.Constraint(
    time=lambda cell: pdt1 <= cell.point < pdt2)
last_slice = anoms.extract(last_daterange) # extract the first slice using date constraints.
print(last_slice)

# Finally, plot it as filled contours with a brewer colormap.

qplt.contourf(last_slice, brewer_cmap.N, cmap=brewer_cmap)

# Add coastlines to the map created by contourf.
plt.gca().coastlines()

plt.show()
```

# Project: classify extreme weather values.

Load Oxford weather station data into a data frame and use outlier detection to classify months as outliers or not - multidimensional cluster detection. Could try coming up with a predictive algorithm for outliers too - ie forecast when they will occur. However with data that is only monthly this has limited possibilities.

https://www.metoffice.gov.uk/pub/data/weather/uk/climate/stationdata/oxforddata.txt

Monthly data are available for a selection of long-running historic stations. The series typically range from 50 to more than 100 years in length.

Our historic station data consists of:

    Mean daily maximum temperature (tmax)
    Mean daily minimum temperature (tmin)
    Days of air frost (af)
    Total rainfall (rain)
    Total sunshine duration (sun) - This is only recorded from 1929 onwards.

Missing data (more than two days missing in a month) have been indicated by "---". Estimated data (where available) have been indicated by "*" after the value.


```python
import pandas as pd # Load the pandas library.
import numpy as np # Load the numpy library.
import seaborn as sns # load a nice plotting library
import matplotlib.pyplot as plt
from pyod.models.knn import KNN # the K nearest neighbours algorithm. (for outlier detection).
from sklearn.neighbors import LocalOutlierFactor  # using one of scikitlearn's outlier detection algorithms: LOF.
from matplotlib.legend_handler import HandlerPathCollection   # To plot the LOF results.
from sklearn import model_selection  # use this for train_test_split
import xgboost as xgb  # a boosted decision tree algorithm.
from datetime import datetime  # For the timer function.
from sklearn.multioutput import MultiOutputRegressor  # used for the xgb parameter optimisation.
from sklearn.model_selection import RandomizedSearchCV, GridSearchCV
from sklearn.model_selection import StratifiedKFold # K fold cross validation - used for the xgb parameter optimisation.

df=pd.read_csv('C:/Users/user/Documents/Mike/2023_job_applications/python_training_2023/oxford_weather_station.csv')  # Load a csv from a folder into a dataframe using the pandas function read_csv().
df.columns  # Print out what the columns are.
df.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>year</th>
      <th>month</th>
      <th>tmax</th>
      <th>tmin</th>
      <th>air_frost_days</th>
      <th>rain_mm</th>
      <th>sun_hrs</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1853</td>
      <td>1</td>
      <td>8.4</td>
      <td>2.7</td>
      <td>4</td>
      <td>62.8</td>
      <td>---</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1853</td>
      <td>2</td>
      <td>3.2</td>
      <td>-1.8</td>
      <td>19</td>
      <td>29.3</td>
      <td>---</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1853</td>
      <td>3</td>
      <td>7.7</td>
      <td>-0.6</td>
      <td>20</td>
      <td>25.9</td>
      <td>---</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1853</td>
      <td>4</td>
      <td>12.6</td>
      <td>4.5</td>
      <td>0</td>
      <td>60.1</td>
      <td>---</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1853</td>
      <td>5</td>
      <td>16.8</td>
      <td>6.1</td>
      <td>0</td>
      <td>59.5</td>
      <td>---</td>
    </tr>
  </tbody>
</table>
</div>




```python
df1 = df # backup store of the df.
df.info() # year and month columns are integers, the rest of the columns are strings because of the * and --- characters they contain.
# Next remove these special characters.
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 2052 entries, 0 to 2051
    Data columns (total 7 columns):
     #   Column          Non-Null Count  Dtype 
    ---  ------          --------------  ----- 
     0   year            2052 non-null   int64 
     1   month           2052 non-null   int64 
     2   tmax            2052 non-null   object
     3   tmin            2052 non-null   object
     4   air_frost_days  2052 non-null   object
     5   rain_mm         2052 non-null   object
     6   sun_hrs         2052 non-null   object
    dtypes: int64(2), object(5)
    memory usage: 112.3+ KB
    


```python
# MEXT: strip out the --- and * (missing data and estimated values - replace missing with NA).

for (index, colname) in enumerate(df.iloc[:,2:7]):
    df[colname] = df[colname].str.replace("*","")
    df[colname] = df[colname].replace("---",np.NaN)
    
df.tail()
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>year</th>
      <th>month</th>
      <th>tmax</th>
      <th>tmin</th>
      <th>air_frost_days</th>
      <th>rain_mm</th>
      <th>sun_hrs</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1853</td>
      <td>1</td>
      <td>8.4</td>
      <td>2.7</td>
      <td>4</td>
      <td>62.8</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1853</td>
      <td>2</td>
      <td>3.2</td>
      <td>-1.8</td>
      <td>19</td>
      <td>29.3</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1853</td>
      <td>3</td>
      <td>7.7</td>
      <td>-0.6</td>
      <td>20</td>
      <td>25.9</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1853</td>
      <td>4</td>
      <td>12.6</td>
      <td>4.5</td>
      <td>0</td>
      <td>60.1</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1853</td>
      <td>5</td>
      <td>16.8</td>
      <td>6.1</td>
      <td>0</td>
      <td>59.5</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
# change the types of columns from "object" to float.
df[['tmax', 'tmin', 'air_frost_days', 'rain_mm', 'sun_hrs']] = df[['tmax', 'tmin', 'air_frost_days', 'rain_mm', 'sun_hrs']].apply(pd.to_numeric)
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 2052 entries, 0 to 2051
    Data columns (total 7 columns):
     #   Column          Non-Null Count  Dtype  
    ---  ------          --------------  -----  
     0   year            2052 non-null   int64  
     1   month           2052 non-null   int64  
     2   tmax            2052 non-null   float64
     3   tmin            2051 non-null   float64
     4   air_frost_days  2051 non-null   float64
     5   rain_mm         2052 non-null   float64
     6   sun_hrs         1140 non-null   float64
    dtypes: float64(5), int64(2)
    memory usage: 112.3 KB
    

### Outlier detection using unsupervised learning: KNN clustering
    
    from pyod.models.knn import KNN # the K nearest neighbours algorithm. 
The Key KNN parameters are
 1) contamination = proportion of outlier that I expect are in the data, eg 0.1 = 10%.
 2) method = how to calculate outliers, options are largest, mean.
 3) metric = how the distance between the n_neighbours is calc'd, eg 'minkowski' (default - a hybrid of euclidean and manhattan), euclidean (or l2), manhattan (or l1), 'mahalanobis' (use for unimodal data - it effectively normalises the data so scales/units aren't important).
 4) n_neighbours = number of neighbours to use when building clusters. Default is 5. Ideally, you will want to run for different KNN models with varying values of n_neighbours and compare the results to determine the optimal number of n_neighbors.

KNN cannot handle categorical data or missing data.


```python
df = df.dropna()  # returns a dataframe where any row with a missing value is removed.
df.info # 1140 rows (it was 2052). Because the sun_hrs column is not populated until 1929.
```




    <bound method DataFrame.info of       year  month  tmax  tmin  air_frost_days  rain_mm  sun_hrs
    912   1929      1   3.7  -1.1            21.0     29.8     43.8
    913   1929      2   3.3  -3.0            19.0     14.1     60.5
    914   1929      3  12.9  -0.1            17.0      1.4    190.2
    915   1929      4  11.8   2.5             6.0     34.3    144.7
    916   1929      5  17.1   6.4             2.0     28.4    240.9
    ...    ...    ...   ...   ...             ...      ...      ...
    2047  2023      8  21.9  13.2             0.0     60.6    182.9
    2048  2023      9  22.7  13.7             0.0     71.7    181.8
    2049  2023     10  17.1   9.6             0.0    125.4    122.0
    2050  2023     11  11.5   5.1             2.0     78.5     85.7
    2051  2023     12  10.3   5.7             5.0    112.0     24.0
    
    [1140 rows x 7 columns]>




```python
# Instantiate KNN with the updated parameters and then train (fit) the model using the dataframe that I cleaned up missing values:
knn = KNN(contamination=0.05,method='mean',n_neighbors=5)  # Assume that 5% of months are outliers.
knn.fit(df)  # Now fit a KNN model to the cleaned up df dataframe.
```




    KNN(algorithm='auto', contamination=0.05, leaf_size=30, method='mean',
      metric='minkowski', metric_params=None, n_jobs=1, n_neighbors=5, p=2,
      radius=1.0)




```python
# The predict method will generate binary labels, either 1 or 0, for each data point. A value of 1 indicates an outlier. Store the results in a pandas Series and filter the predicted Series to only show the outlier values
predicted = pd.Series(knn.predict(df),index=df.index) 
```


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    Cell In[47], line 2
          1 # The predict method will generate binary labels, either 1 or 0, for each data point. A value of 1 indicates an outlier. Store the results in a pandas Series and filter the predicted Series to only show the outlier values
    ----> 2 predicted = pd.Series(knn.predict(df),index=df.index)
    

    File ~\anaconda3\Lib\site-packages\pyod\models\base.py:168, in BaseDetector.predict(self, X, return_confidence)
        147 """Predict if a particular sample is an outlier or not.
        148 
        149 Parameters
       (...)
        164     Only if return_confidence is set to True.
        165 """
        167 check_is_fitted(self, ['decision_scores_', 'threshold_', 'labels_'])
    --> 168 pred_score = self.decision_function(X)
        170 if isinstance(self.contamination, (float, int)):
        171     prediction = (pred_score > self.threshold_).astype('int').ravel()
    

    File ~\anaconda3\Lib\site-packages\pyod\models\knn.py:250, in KNN.decision_function(self, X)
        247 x_i = np.asarray(x_i).reshape(1, x_i.shape[0])
        249 # get the distance of the current point
    --> 250 dist_arr, _ = self.tree_.query(x_i, k=self.n_neighbors)
        251 dist = self._get_dist_by_method(dist_arr)
        252 pred_score_i = dist[-1]
    

    File sklearn\neighbors\_binary_tree.pxi:1119, in sklearn.neighbors._kd_tree.BinaryTree.query()
    

    ValueError: query data dimension must match training data dimension



```python
knn_scores = knn.decision_scores_  # extract the decision scores from the KNN fit.

abc = pd.DataFrame(knn_scores) # convert to a df.

abc.index = df.index # change the index on abc so I can tell which row matches df.

abc = abc.rename(columns = {0:'scores'})  # to rename the column.

# Since all the data points are scored, PyOD will determine a threshold to limit the number of outliers returned. The threshold value depends on the contamination value you provided earlier (the proportion of outliers you suspect). The higher the contamination value, the lower the threshold, and hence more outliers are returned. 
knn.threshold_ # get the threshold value using the threshold_ attribute
```




    21.996786897612793




```python
# Now find the rows in abc which exceed the threshold score, ie have been classified as outliers.
abc[abc['scores'] >= knn.threshold_].sort_values('scores', ascending=False) # There are 57. 5% good.
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2013</th>
      <td>57.583906</td>
    </tr>
    <tr>
      <th>1842</th>
      <td>52.403178</td>
    </tr>
    <tr>
      <th>2008</th>
      <td>46.605845</td>
    </tr>
    <tr>
      <th>1289</th>
      <td>44.415987</td>
    </tr>
    <tr>
      <th>1054</th>
      <td>38.532908</td>
    </tr>
    <tr>
      <th>1253</th>
      <td>36.861314</td>
    </tr>
    <tr>
      <th>1643</th>
      <td>35.556014</td>
    </tr>
    <tr>
      <th>1445</th>
      <td>35.046458</td>
    </tr>
    <tr>
      <th>1161</th>
      <td>34.490655</td>
    </tr>
    <tr>
      <th>922</th>
      <td>34.387435</td>
    </tr>
    <tr>
      <th>983</th>
      <td>33.666056</td>
    </tr>
    <tr>
      <th>1144</th>
      <td>33.029528</td>
    </tr>
    <tr>
      <th>2051</th>
      <td>32.353836</td>
    </tr>
    <tr>
      <th>1819</th>
      <td>31.962066</td>
    </tr>
    <tr>
      <th>1170</th>
      <td>31.507078</td>
    </tr>
    <tr>
      <th>1932</th>
      <td>31.300488</td>
    </tr>
    <tr>
      <th>1895</th>
      <td>31.260321</td>
    </tr>
    <tr>
      <th>989</th>
      <td>30.917215</td>
    </tr>
    <tr>
      <th>1926</th>
      <td>30.848455</td>
    </tr>
    <tr>
      <th>1278</th>
      <td>30.541497</td>
    </tr>
    <tr>
      <th>1062</th>
      <td>30.340773</td>
    </tr>
    <tr>
      <th>1516</th>
      <td>29.866176</td>
    </tr>
    <tr>
      <th>1228</th>
      <td>28.661233</td>
    </tr>
    <tr>
      <th>1986</th>
      <td>28.279850</td>
    </tr>
    <tr>
      <th>952</th>
      <td>27.915129</td>
    </tr>
    <tr>
      <th>1984</th>
      <td>27.346346</td>
    </tr>
    <tr>
      <th>2049</th>
      <td>27.010240</td>
    </tr>
    <tr>
      <th>1852</th>
      <td>26.885568</td>
    </tr>
    <tr>
      <th>1460</th>
      <td>26.768925</td>
    </tr>
    <tr>
      <th>1662</th>
      <td>26.169088</td>
    </tr>
    <tr>
      <th>1129</th>
      <td>25.924631</td>
    </tr>
    <tr>
      <th>935</th>
      <td>25.848611</td>
    </tr>
    <tr>
      <th>1414</th>
      <td>25.808860</td>
    </tr>
    <tr>
      <th>2016</th>
      <td>25.711521</td>
    </tr>
    <tr>
      <th>1617</th>
      <td>25.673277</td>
    </tr>
    <tr>
      <th>1044</th>
      <td>25.567589</td>
    </tr>
    <tr>
      <th>1798</th>
      <td>24.671033</td>
    </tr>
    <tr>
      <th>1226</th>
      <td>24.486720</td>
    </tr>
    <tr>
      <th>1374</th>
      <td>24.201749</td>
    </tr>
    <tr>
      <th>2033</th>
      <td>23.992714</td>
    </tr>
    <tr>
      <th>957</th>
      <td>23.987126</td>
    </tr>
    <tr>
      <th>1913</th>
      <td>23.979241</td>
    </tr>
    <tr>
      <th>923</th>
      <td>23.890638</td>
    </tr>
    <tr>
      <th>914</th>
      <td>23.816072</td>
    </tr>
    <tr>
      <th>1184</th>
      <td>23.809610</td>
    </tr>
    <tr>
      <th>1469</th>
      <td>23.740522</td>
    </tr>
    <tr>
      <th>1938</th>
      <td>23.545494</td>
    </tr>
    <tr>
      <th>992</th>
      <td>23.208333</td>
    </tr>
    <tr>
      <th>1589</th>
      <td>23.180614</td>
    </tr>
    <tr>
      <th>938</th>
      <td>23.081118</td>
    </tr>
    <tr>
      <th>1041</th>
      <td>22.708871</td>
    </tr>
    <tr>
      <th>1247</th>
      <td>22.677337</td>
    </tr>
    <tr>
      <th>1130</th>
      <td>22.675137</td>
    </tr>
    <tr>
      <th>1072</th>
      <td>22.572577</td>
    </tr>
    <tr>
      <th>1045</th>
      <td>22.571422</td>
    </tr>
    <tr>
      <th>1575</th>
      <td>22.240502</td>
    </tr>
    <tr>
      <th>1711</th>
      <td>22.231661</td>
    </tr>
  </tbody>
</table>
</div>




```python
ix = ( abc['scores'] > knn.threshold_ ) # create a mask. a boolean list depending on whether that row is above the threshold.
df['outlier'] = ix # add a column that contains the outlier classification.
```

    C:\Users\User\AppData\Local\Temp\ipykernel_26720\1230124455.py:2: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df['outlier'] = ix # add a column that contains the outlier classification.
    


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>year</th>
      <th>month</th>
      <th>tmax</th>
      <th>tmin</th>
      <th>air_frost_days</th>
      <th>rain_mm</th>
      <th>sun_hrs</th>
      <th>outlier</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>912</th>
      <td>1929</td>
      <td>1</td>
      <td>3.7</td>
      <td>-1.1</td>
      <td>21.0</td>
      <td>29.8</td>
      <td>43.8</td>
      <td>False</td>
    </tr>
    <tr>
      <th>913</th>
      <td>1929</td>
      <td>2</td>
      <td>3.3</td>
      <td>-3.0</td>
      <td>19.0</td>
      <td>14.1</td>
      <td>60.5</td>
      <td>False</td>
    </tr>
    <tr>
      <th>914</th>
      <td>1929</td>
      <td>3</td>
      <td>12.9</td>
      <td>-0.1</td>
      <td>17.0</td>
      <td>1.4</td>
      <td>190.2</td>
      <td>True</td>
    </tr>
    <tr>
      <th>915</th>
      <td>1929</td>
      <td>4</td>
      <td>11.8</td>
      <td>2.5</td>
      <td>6.0</td>
      <td>34.3</td>
      <td>144.7</td>
      <td>False</td>
    </tr>
    <tr>
      <th>916</th>
      <td>1929</td>
      <td>5</td>
      <td>17.1</td>
      <td>6.4</td>
      <td>2.0</td>
      <td>28.4</td>
      <td>240.9</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.pairplot(data=df, hue='outlier')  # Use a pairplot to examine the multidimensional data.
plt.savefig("oxford_scatterplot_outliers.png")
```

    C:\Users\User\anaconda3\Lib\site-packages\seaborn\axisgrid.py:118: UserWarning: The figure layout has changed to tight
      self._figure.tight_layout(*args, **kwargs)
    


    
![png](output_90_1.png)
    


The scatter plot matrix is really useful. It shows
 - bimodal distributions for temperature and sunshine
 - strong correlations of temperature min and max
 - strong correlations of tmax with sun_hrs and air_frost_days
 - the outliers (orange points) are not just high and low values in one or two variables. Instead they can be seen to be scattered amongst all the dimensions, suggesting that the algorithm has successfully identified multidimensional outliers
 - the scatterplot of sun_hrs and rain_mm is perhaps the most interesting with extreme values existing in all the edges of the chart, except for low rain_mm.


```python

```




    (57, 1)




```python

```
